// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;


import frc.robot.Constants.RollerConstants;
import frc.robot.lib.PIDGains;
import com.revrobotics.CANSparkBase.ControlType;
import com.revrobotics.CANSparkBase.IdleMode;
import com.revrobotics.CANSparkLowLevel.MotorType;
import com.revrobotics.CANSparkMax;
import com.revrobotics.RelativeEncoder;
import com.revrobotics.SparkPIDController;
import com.revrobotics.SparkRelativeEncoder;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

/** Class to run the rollers over CAN */
public class CANRollerSubsystem extends SubsystemBase {
  private final CANSparkMax rollerMotor;
  private RelativeEncoder rollerEncoder;
  private SparkPIDController rollerController;

  private boolean rollerPositionMode;
  private double rollerTargetPosition;
  private double rollerPower;


  public CANRollerSubsystem() {
    // Set up the roller motor as a brushed motor
    rollerMotor = new CANSparkMax(RollerConstants.ROLLER_MOTOR_ID, MotorType.kBrushless);
    rollerMotor.setInverted(false);
    rollerMotor.setSmartCurrentLimit(RollerConstants.ROLLER_MOTOR_CURRENT_LIMIT);
    rollerMotor.setIdleMode(IdleMode.kBrake);

    rollerEncoder = rollerMotor.getEncoder(SparkRelativeEncoder.Type.kHallSensor, 42);

    rollerController = rollerMotor.getPIDController();
    PIDGains.setSparkMaxGains(rollerController, RollerConstants.ROLLER_POSITION_GAINS);

    rollerMotor.burnFlash();

    rollerPositionMode = false;
    rollerTargetPosition = m_encoder.getPosition();
    rollerPower = 0.0;

    // Set can timeout. Because this project only sets parameters once on
    // construction, the timeout can be long without blocking robot operation. Code
    // which sets or gets parameters during operation may need a shorter timeout.
    rollerMotor.setCANTimeout(250);

    // Create and apply configuration for roller motor. Voltage compensation helps
    // the roller behave the same as the battery
    // voltage dips. The current limit helps prevent breaker trips or burning out
    // the motor in the event the roller stalls.

    /*
    CANSparkMaxConfig rollerConfig = new CANSparkMaxConfig();
    rollerConfig.voltageCompensation(RollerConstants.ROLLER_MOTOR_VOLTAGE_COMP);
    rollerConfig.smartCurrentLimit(RollerConstants.ROLLER_MOTOR_CURRENT_LIMIT);
    rollerMotor.configure(rollerConfig, ResetMode.kResetSafeParameters, PersistMode.kPersistParameters);
    */
  }

  @Override
  public void periodic() {
  }

  /** This is a method that makes the roller spin */
  public void runRoller(double forward, double reverse) {
    rollerMotor.set(forward - reverse);
  }
}
